
import React, { useEffect, useRef, useState, useMemo } from "react";

/**
 * Gracias Africa — mobile‑friendly, Mario‑inspired* mini‑adventure with 4 checkpoints.
 * (*original art & sounds; no Nintendo assets used)
 *
 * Desktop: ← → to move / lanes; Space to interact; Enter to start.
 * Mobile: on‑screen left/right + Action buttons; swipe on lane level; drag on fishing.
 */

export default function App() {
  const [screen, setScreen] = useState("menu");
  const [meta, setMeta] = useState({
    heroName: "3’bya",
    outfit: "Grey & Navy",
    difficulty: "Medium",
  });

  useEffect(() => { document.title = "Gracias Africa"; }, []);

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-slate-50 flex flex-col items-center">
      <Header />
      {screen === "menu" && (
        <MainMenu onStart={() => setScreen("c1")} meta={meta} setMeta={setMeta} />
      )}
      {screen === "c1" && (
        <Checkpoint1 onFail={() => setScreen("c1")} onPass={() => setScreen("c2")} />
      )}
      {screen === "c2" && (
        <Checkpoint2 onFail={() => setScreen("c2")} onPass={() => setScreen("c3")} />
      )}
      {screen === "c3" && (
        <Checkpoint3 onFail={() => setScreen("c3")} onPass={() => setScreen("c4")} />
      )}
      {screen === "c4" && (
        <Checkpoint4 onFail={() => setScreen("c4")} onWin={() => setScreen("win")} />
      )}
      {screen === "win" && <WinScreen onReplay={() => setScreen("menu")} />}
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <div className="w-full max-w-5xl px-4 pt-6 pb-2">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
          Gracias Africa
        </h1>
        <span className="text-xs md:text-sm opacity-80">Share the link after deploy</span>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <div className="w-full max-w-5xl px-4 py-4 opacity-70 text-xs">
      *Mario‑inspired vibe, but all original art/sounds. Keyboard + touch supported.
    </div>
  );
}

function Card({ children, className = "" }) {
  return (
    <div className={`w-full max-w-5xl rounded-2xl bg-slate-800/50 shadow-xl border border-slate-700 ${className}`}>
      <div className="p-4 md:p-6">{children}</div>
    </div>
  );
}

function MainMenu({ onStart, meta, setMeta }) {
  useEnterToStart(onStart);
  return (
    <Card>
      <div className="grid md:grid-cols-2 gap-6 items-center">
        <HeroPreview />
        <div>
          <h2 className="text-xl font-semibold mb-2">Your Hero</h2>
          <div className="space-y-2 text-sm">
            <div>Name: <b>{meta.heroName}</b></div>
            <div>Outfit: <b>{meta.outfit}</b></div>
            <div>Difficulty: <b>{meta.difficulty}</b></div>
          </div>
          <button
            onClick={onStart}
            className="mt-6 inline-flex items-center gap-2 rounded-xl px-5 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-900 font-semibold shadow-lg"
          >
            ▶ Start Adventure
          </button>
          <p className="mt-3 text-xs opacity-80">Desktop: Enter. Mobile: tap Start.</p>
        </div>
      </div>
      <BGMControls />
    </Card>
  );
}

function HeroPreview() {
  // Simple avatar illustration for 3’bya
  return (
    <div className="relative w-full aspect-[16/10] rounded-xl bg-gradient-to-br from-indigo-900 to-indigo-700 overflow-hidden">
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white/40 to-transparent" />
      <div className="absolute left-6 bottom-6">
        <HeroSprite scale={2.2} />
        <div className="mt-2 text-xs opacity-80">3’bya • Grey & Navy Explorer</div>
      </div>
      <FloatingText text="Checkpoint 1: Land in the Safari" top="18%" left="60%" />
      <FloatingText text="Checkpoint 2: Catch 3 Fish / 3m" top="50%" left="70%" />
      <FloatingText text="Checkpoint 3: 5 ❤ before 2 🐒" top="72%" left="40%" />
      <FloatingText text="Checkpoint 4: Hug Bzr to win" top="30%" left="24%" />
      <div className="absolute right-4 top-4 text-[10px] bg-black/30 px-2 py-1 rounded-md">Logo: Bzr tantrum</div>
    </div>
  );
}

function FloatingText({ text, top = "50%", left = "50%" }) {
  return (
    <div className="absolute text-[11px] md:text-sm opacity-90 bg-black/30 px-2 py-1 rounded-md"
      style={{ top, left, transform: "translate(-50%, -50%)" }}>
      {text}
    </div>
  );
}

/** UTIL: Audio bus + beeps + chiptune BGM */
const AudioBus = {
  ctx: typeof window !== "undefined" ? new (window.AudioContext || window.webkitAudioContext)() : null,
};

const Sound = {
  beep(freq = 880, time = 0.08) {
    if (!AudioBus.ctx) return;
    const o = AudioBus.ctx.createOscillator();
    const g = AudioBus.ctx.createGain();
    o.connect(g); g.connect(AudioBus.ctx.destination);
    o.type = "square"; o.frequency.value = freq;
    g.gain.value = 0.06;
    o.start();
    o.stop(AudioBus.ctx.currentTime + time);
  },
  boo() { this.beep(160, 0.18); this.beep(140, 0.2); },
  yay() { this.beep(660, 0.08); this.beep(880, 0.1); this.beep(990, 0.08); },
};

/** Simple, copyright-safe chiptune loop */
function BGMControls() {
  const [playing, setPlaying] = useState(false);

  useEffect(()=>() => stopTune(), []);

  function startTune(){
    if (!AudioBus.ctx) return;
    const ctx = AudioBus.ctx;
    const master = ctx.createGain(); master.gain.value = 0.05; master.connect(ctx.destination);
    const tempo = 120; const beat = 60/tempo;
    const notes = [0,2,4,5,7,9,11,12]; const base = 220;

    const osc1 = ctx.createOscillator(), g1 = ctx.createGain();
    osc1.type = "square"; osc1.connect(g1); g1.connect(master);
    const osc2 = ctx.createOscillator(), g2 = ctx.createGain();
    osc2.type = "triangle"; osc2.connect(g2); g2.connect(master);

    const start = ctx.currentTime + 0.05, steps = 32;
    for (let i=0;i<steps;i++){
      const t = start + i*(beat/2);
      const n1 = base * (2 ** (notes[i%notes.length]/12));
      const n2 = (base/2) * (2 ** ((notes[(i*3)%notes.length]-12)/12));
      osc1.frequency.setValueAtTime(n1, t); g1.gain.setValueAtTime(0.3, t); g1.gain.exponentialRampToValueAtTime(0.0001, t + beat/2*0.9);
      osc2.frequency.setValueAtTime(n2, t); g2.gain.setValueAtTime(0.15, t); g2.gain.exponentialRampToValueAtTime(0.0001, t + beat/2*0.9);
    }
    const stopAt = start + steps*(beat/2) + 0.02;
    osc1.start(start); osc2.start(start); osc1.stop(stopAt); osc2.stop(stopAt);
    window.__ga_bgm = { master, restart: ()=>setTimeout(startTune, (stopAt-ctx.currentTime)*1000) };
    setTimeout(()=>{ if (window.__ga_bgm) window.__ga_bgm.restart() }, (stopAt-ctx.currentTime)*1000);
  }

  function stopTune(){ if (window.__ga_bgm){ window.__ga_bgm.master.disconnect(); window.__ga_bgm = null; } }

  return (
    <div className="mt-4 flex items-center gap-2 text-xs">
      <button onClick={()=>{ if (!playing){ startTune(); setPlaying(true); } else { stopTune(); setPlaying(false); } }}
        className="rounded-lg px-3 py-1.5 bg-slate-900/70 border border-slate-700 hover:bg-slate-900">
        {playing ? "🔊 Music: On (tap to stop)" : "🔈 Music: Off (tap to play)"}
      </button>
      <span className="opacity-70">Procedural chiptune (safe)</span>
    </div>
  );
}

function useEnterToStart(fn) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Enter") fn(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [fn]);
}

/** Mobile Controls Overlay (shows on small screens) */
function ControlsOverlay({ onLeft, onRight, onAction, label = "Action" }) {
  return (
    <div className="fixed inset-x-0 bottom-0 md:hidden z-40 flex items-center justify-center gap-4 pb-6">
      <div className="flex items-center gap-3 rounded-2xl bg-slate-900/70 backdrop-blur border border-slate-700 px-4 py-3 shadow-2xl">
        <button onClick={onLeft} className="h-12 w-12 rounded-xl bg-slate-800 active:scale-95 border border-slate-700 text-xl" aria-label="Left">←</button>
        <button onClick={onAction} className="h-12 px-4 rounded-xl bg-emerald-500 text-slate-900 font-semibold active:scale-95">{label}</button>
        <button onClick={onRight} className="h-12 w-12 rounded-xl bg-slate-800 active:scale-95 border border-slate-700 text-xl" aria-label="Right">→</button>
      </div>
    </div>
  );
}

/** CHECKPOINT 1 — Land the Plane on Safari Plains */
function Checkpoint1({ onFail, onPass }) {
  const options = useMemo(() => ([
    { id: "safari", label: "Safari Plains", emoji: "🦒🐘🦓🐒🦛🐎", good: true, color: "#1b8f3f" },
    { id: "beach", label: "Sunset Beach", emoji: "🏝️🌊🪸", good: false, color: "#0ea5e9" },
    { id: "city", label: "Neon City", emoji: "🏙️🚕✨", good: false, color: "#64748b" },
    { id: "desert", label: "Dune Desert", emoji: "🏜️🐪☀️", good: false, color: "#eab308" },
    { id: "mountain", label: "Crystal Peaks", emoji: "🏔️🌲❄️", good: false, color: "#60a5fa" },
  ]), []);

  const [hint, setHint] = useState("Tap the animal‑rich green plains.");

  return (
    <Card>
      <LevelHeader n={1} subtitle="Choose the correct landing zone" />
      <div className="grid md:grid-cols-2 gap-6">
        <CanvasSkyPlane />
        <div>
          <p className="text-sm opacity-90 mb-3">Tap a zone to land. Only one is correct. Wrong landings repeat the checkpoint.</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {options.map((opt) => (
              <button key={opt.id}
                onClick={() => {
                  if (opt.good) { Sound.yay(); onPass(); }
                  else { Sound.boo(); setHint(`Oops — ${opt.label} was wrong. Try again!`); }
                }}
                className="rounded-xl px-4 py-4 text-left bg-slate-900/60 border border-slate-700 hover:bg-slate-900 transition shadow-md">
                <div className="flex items-center justify-between">
                    <span className="font-semibold">{opt.label}</span>
                    <span className="text-xl">{opt.emoji}</span>
                </div>
                <div className="mt-2 h-1.5 w-full rounded-full" style={{background: opt.color}} />
              </button>
            ))}
          </div>
          <div className="mt-4 text-xs opacity-80">Hint: green, teeming with wildlife 🐘🦒🦓</div>
          <div className="mt-1 text-xs opacity-80">{hint}</div>
        </div>
      </div>
    </Card>
  );
}

function CanvasSkyPlane() {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current; const ctx = c.getContext("2d");
    let w = c.width = c.offsetWidth; let h = c.height = Math.floor(c.offsetWidth * 0.56);
    const dpi = window.devicePixelRatio || 1; c.width = w * dpi; c.height = h * dpi; ctx.scale(dpi, dpi);
    const grd = ctx.createLinearGradient(0,0,0,h);
    grd.addColorStop(0,"#0ea5e9"); grd.addColorStop(1,"#1e293b");
    ctx.fillStyle = grd; ctx.fillRect(0,0,w,h);

    for (let i=0;i<7;i++) { drawCloud(ctx, Math.random()*w, 40+Math.random()*120, 40+Math.random()*60); }

    ctx.save();
    ctx.translate(w*0.2, h*0.55);
    ctx.rotate(-0.07);
    ctx.fillStyle = "#93c5fd"; roundRect(ctx, -70, -16, 140, 32, 16); ctx.fill();
    ctx.fillStyle = "#0ea5e9"; roundRect(ctx, -48, -10, 96, 20, 10); ctx.fill();
    ctx.fillStyle = "#e2e8f0"; roundRect(ctx, 40, -6, 18, 12, 4); ctx.fill();
    ctx.fillStyle = "#64748b"; ctx.beginPath(); ctx.moveTo(-10,-6); ctx.lineTo(70,-48); ctx.lineTo(40,-8); ctx.closePath(); ctx.fill();
    ctx.restore();

    const zones = [
      {x:w*0.12, y:h*0.86, txt:"Safari Plains"},
      {x:w*0.40, y:h*0.86, txt:"Sunset Beach"},
      {x:w*0.68, y:h*0.86, txt:"Neon City"},
    ];
    ctx.fillStyle = "#fff"; ctx.font = "12px ui-sans-serif"; ctx.globalAlpha = 0.9;
    zones.forEach(z=>{ ctx.fillText(z.txt, z.x-30, z.y); });
  }, []);
  return <div className="relative">
    <canvas ref={ref} className="w-full rounded-xl border border-slate-700 bg-black/20" />
    <div className="absolute bottom-2 left-2 bg-black/40 text-xs px-2 py-1 rounded-md">Art preview</div>
  </div>
}

/** CHECKPOINT 2 — Beach Fishing: Catch 3 Fish within 3 minutes */
function Checkpoint2({ onFail, onPass }) {
  const [catches, setCatches] = useState(0);
  const [timeLeft, setTimeLeft] = useState(180);
  const [running, setRunning] = useState(true);
  const [msg, setMsg] = useState("Catch 3 fish within 3 minutes. Move with ← → or drag. Tap Action to cast.");
  const fishRef = useRef([]);
  const hookX = useRef(0.5);
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!running) return; if (timeLeft<=0) { Sound.boo(); setMsg("Time's up! Try again."); resetRound(true); return; }
    const t = setTimeout(()=>setTimeLeft(t=>t-1), 1000);
    return ()=>clearTimeout(t);
  }, [timeLeft, running]);

  function resetRound(repeat=false) {
    setRunning(false);
    setTimeout(()=>{
      setCatches(0); setTimeLeft(180); setRunning(true);
      fishRef.current = []; setMsg(repeat?"Catch 3 fish — round restarted!":"Catch 3 fish within 3 minutes.");
      draw(true);
    }, 800);
  }

  useEffect(()=>{
    const onKey = (e)=>{
      if (e.key === "ArrowLeft") hookX.current = Math.max(0, hookX.current - 0.06);
      if (e.key === "ArrowRight") hookX.current = Math.min(1, hookX.current + 0.06);
      if (e.key === " ") tryCatch();
    };
    window.addEventListener("keydown", onKey);
    return ()=>window.removeEventListener("keydown", onKey);
  }, []);

  function tryCatch() {
    const fish = fishRef.current.find(f => Math.abs(f.x - hookX.current) < 0.06 && f.y > 0.58 && !f.caught);
    if (fish) {
      fish.caught = true; setCatches(v=>v+1); Sound.yay(); setMsg("Nice catch!");
      if (catches+1 >= 3) { setTimeout(()=>onPass(), 400); }
    } else {
      Sound.beep(220,0.05); setMsg("Missed — time your cast when fish are near the hook.");
    }
  }

  useEffect(()=>{ draw(true); }, []);
  function draw(start=false) {
    const c = canvasRef.current; if (!c) return; const ctx = c.getContext("2d");
    const w = c.width = c.offsetWidth; const h = c.height = Math.floor(w*0.56);
    const dpi = window.devicePixelRatio||1; c.width=w*dpi; c.height=h*dpi; ctx.scale(dpi,dpi);

    let last = 0;
    function tick(t){
      const dt = Math.min(32, t-last); last=t; paint(ctx,w,h,dt); requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  function paint(ctx,w,h,dt){
    const sky = ctx.createLinearGradient(0,0,0,h);
    sky.addColorStop(0,"#60a5fa"); sky.addColorStop(0.45,"#93c5fd"); sky.addColorStop(0.46,"#0ea5e9"); sky.addColorStop(1,"#0369a1");
    ctx.fillStyle = sky; ctx.fillRect(0,0,w,h);

    ctx.fillStyle = "#fde047"; ctx.beginPath(); ctx.arc(w*0.85,h*0.18,18,0,Math.PI*2); ctx.fill();
    ctx.fillStyle = "#f5d0fe"; ctx.fillRect(0,h*0.62,w, h*0.08);
    ctx.fillStyle = "#fbbf24"; ctx.fillRect(0,h*0.70,w, h*0.30);

    const hx = w*hookX.current; const hy = h*0.58;
    ctx.strokeStyle = "#e2e8f0"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(hx,0); ctx.lineTo(hx,hy); ctx.stroke();
    ctx.fillStyle = "#94a3b8"; ctx.beginPath(); ctx.arc(hx, hy, 6, 0, Math.PI*2); ctx.fill();

    if (Math.random()<0.03 && fishRef.current.length<12) {
      fishRef.current.push({ x: Math.random(), y: 0.62 + Math.random()*0.25, dir: Math.random()<0.5?-1:1, speed: 0.1+Math.random()*0.2, caught:false });
    }

    fishRef.current.forEach(f => { f.x += f.dir * f.speed * (dt/1000); if (f.x<-0.1||f.x>1.1) { f.dir*=-1; f.x = Math.max(-0.1, Math.min(1.1,f.x)); }
      const x = w*f.x; const y = h*f.y; ctx.save(); ctx.translate(x,y);
      ctx.scale(f.dir,1); drawFish(ctx); ctx.restore();
    });
  }

  return (
    <Card>
      <LevelHeader n={2} subtitle="Beach — Catch 3 fish in 3 minutes (Medium)" />
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <div className="flex items-center justify-between text-sm mb-2">
            <div>🎯 Caught: <b>{catches}</b> / 3</div>
            <div>⏱️ Time: <b>{formatTime(timeLeft)}</b></div>
          </div>
          <div className="text-xs opacity-90 mb-3">Use ← → or drag on water to position the hook. Tap Action to cast.</div>
          <div className="rounded-xl overflow-hidden border border-slate-700 bg-black/30">
            <canvas ref={canvasRef} className="w-full"
              onPointerDown={(e)=>{
                const rect = e.currentTarget.getBoundingClientRect();
                hookX.current = Math.min(1, Math.max(0, (e.clientX - rect.left)/rect.width));
              }}
              onPointerMove={(e)=>{
                if (e.buttons!==1 && e.pointerType!=="touch") return;
                const rect = e.currentTarget.getBoundingClientRect();
                hookX.current = Math.min(1, Math.max(0, (e.clientX - rect.left)/rect.width));
              }}
            />
          </div>
          <div className="mt-2 text-xs opacity-90">{msg}</div>
        </div>
        <div className="flex flex-col gap-3">
          <Tip title="Timing">Fish move in waves. Cast when they align with your hook near the waterline.</Tip>
          <Tip title="Missed?">If the timer hits 0 before 3 fish, the round restarts automatically.</Tip>
          <button onClick={()=>{Sound.boo(); setMsg("You gave up — restarting."); resetRound(true);}}
            className="mt-2 self-start rounded-xl px-4 py-2 bg-slate-900/60 border border-slate-700 hover:bg-slate-900">Restart Round</button>
        </div>
      </div>
      <ControlsOverlay onLeft={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowLeft'}))}
                       onRight={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowRight'}))}
                       onAction={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:' '}))}
                       label="Action" />
    </Card>
  );
}

/** CHECKPOINT 3 — 4‑Wheeler Lanes: Collect 5 ❤, avoid 2 🐒 */
function Checkpoint3({ onFail, onPass }) {
  const lanes = [0.25, 0.5, 0.75];
  const [lane, setLane] = useState(1);
  const [hearts, setHearts] = useState(0);
  const [monkeys, setMonkeys] = useState(0);
  const [status, setStatus] = useState("Collect 5 hearts before hitting 2 monkeys.");
  const canvasRef = useRef(null);
  const objects = useRef([]);
  const touchStartX = useRef(null);

  useEffect(()=>{
    const onKey = (e)=>{
      if (e.key === "ArrowLeft") setLane(v=>Math.max(0, v-1));
      if (e.key === "ArrowRight") setLane(v=>Math.min(2, v+1));
    };
    window.addEventListener("keydown", onKey);
    return ()=>window.removeEventListener("keydown", onKey);
  },[]);

  useEffect(()=>{ draw(); },[]);

  useEffect(()=>{
    if (hearts>=5) { Sound.yay(); setTimeout(()=>onPass(), 400); }
    if (monkeys>=2) { Sound.boo(); setStatus("Ouch — two monkeys! Try again."); setTimeout(()=>{ setHearts(0); setMonkeys(0); objects.current=[]; }, 600); }
  }, [hearts, monkeys]);

  function draw(){
    const c = canvasRef.current; const ctx = c.getContext("2d");
    let w = c.width = c.offsetWidth; let h = c.height = Math.floor(w*0.56);
    const dpi = window.devicePixelRatio||1; c.width=w*dpi; c.height=h*dpi; ctx.scale(dpi,dpi);
    let last = 0;
    function tick(t){ const dt = Math.min(32, t-last); last=t; paint(ctx,w,h,dt); requestAnimationFrame(tick);} requestAnimationFrame(tick);
  }

  function paint(ctx,w,h,dt){
    ctx.fillStyle = "#064e3b"; ctx.fillRect(0,0,w,h);
    ctx.fillStyle = "#065f46"; ctx.fillRect(w*0.1,0,w*0.8,h);
    ctx.strokeStyle = "#10b981"; ctx.setLineDash([10,12]); ctx.lineWidth=3; ctx.beginPath();
    [0.33, 0.66].forEach(p=>{ ctx.moveTo(w*(0.1+p*0.8),0); ctx.lineTo(w*(0.1+p*0.8),h); }); ctx.stroke(); ctx.setLineDash([]);

    if (Math.random()<0.03 && objects.current.length<10) {
      const isHeart = Math.random() < 0.6;
      objects.current.push({ lane: Math.floor(Math.random()*3), y: -40, type: isHeart?"heart":"monkey", speed: 0.25+Math.random()*0.35 });
    }

    const carX = w*(0.1 + lanes[lane]*0.8); const carY = h*0.78; drawQuadBike(ctx, carX, carY);

    objects.current.forEach(o=>{ o.y += o.speed * (dt);
      const x = w*(0.1 + lanes[o.lane]*0.8); const y=o.y; drawLaneObj(ctx, x, y, o.type);
      if (Math.abs(y - carY) < 36 && Math.abs(x - carX) < 28) {
        o.hit = true;
        if (o.type==='heart') { setHearts(v=>v+1); Sound.beep(700,0.07); setStatus("+1 ❤"); }
        else { setMonkeys(v=>v+1); Sound.beep(200,0.09); setStatus("Hit a monkey!" ); }
      }
    });
    objects.current = objects.current.filter(o=>!o.hit && o.y<h+60);

    ctx.fillStyle = "#fff"; ctx.font = "bold 14px ui-sans-serif";
    ctx.fillText(`❤ ${hearts}/5`, 12, 20);
    ctx.fillText(`🐒 ${monkeys}/2`, 12, 38);
  }

  return (
    <Card>
      <LevelHeader n={3} subtitle="4‑Wheeler — get 5 ❤ before 2 🐒" />
      <div className="grid md:grid-cols-2 gap-6 items-start">
        <div className="rounded-xl overflow-hidden border border-slate-700 bg-black/30"
             onTouchStart={(e)=>{ touchStartX.current = e.changedTouches[0].clientX; }}
             onTouchEnd={(e)=>{ const dx = e.changedTouches[0].clientX - (touchStartX.current ?? 0); if (Math.abs(dx)>30){ if (dx<0) setLane(v=>Math.max(0,v-1)); else setLane(v=>Math.min(2,v+1)); } }}>
          <canvas ref={canvasRef} className="w-full" />
        </div>
        <div className="text-sm">
          <p className="opacity-90">Swipe left/right or use on-screen arrows. Collect hearts, avoid monkeys.</p>
          <p className="mt-2 text-xs opacity-80">{status}</p>
          <div className="mt-4 text-xs opacity-70">Tip: anticipate spawn patterns — hearts are slightly more common than monkeys.</div>
        </div>
      </div>
      <ControlsOverlay onLeft={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowLeft'}))}
                       onRight={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowRight'}))}
                       onAction={()=>{ /* no special action here */ }}
                       label="" />
    </Card>
  );
}

/** CHECKPOINT 4 — Key & Door, then a Choice */
function Checkpoint4({ onFail, onWin }) {
  const canvasRef = useRef(null);
  const [hasKey, setHasKey] = useState(false);
  const [stage, setStage] = useState("find"); // find -> choose

  useEffect(()=>{ draw(); },[]);

  function draw(){
    const c = canvasRef.current; const ctx = c.getContext("2d");
    let w = c.width = c.offsetWidth; let h = c.height = Math.floor(w*0.56);
    const dpi = window.devicePixelRatio||1; c.width=w*dpi; c.height=h*dpi; ctx.scale(dpi,dpi);

    let heroX = 0.2; // 0..1
    let doorX = 0.8; let keyX = 0.45; let last=0;

    function onKey(e){
      if (stage!=="find") return;
      if (e.key==="ArrowLeft") heroX = Math.max(0.05, heroX - 0.04);
      if (e.key==="ArrowRight") heroX = Math.min(0.95, heroX + 0.04);
      if (e.key===" ") {
        if (!hasKey && Math.abs(heroX - keyX) < 0.05) { setHasKey(true); Sound.yay(); }
        if (hasKey && Math.abs(heroX - doorX) < 0.05) { setStage("choose"); Sound.beep(520,0.08); }
      }
    }
    window.addEventListener("keydown", onKey);

    function tick(t){ const dt = Math.min(32, t-last); last=t; paint(ctx,w,h,dt); requestAnimationFrame(tick); }
    requestAnimationFrame(tick);

    function paint(ctx,w,h,dt){
      const g = ctx.createLinearGradient(0,0,0,h); g.addColorStop(0,"#991b1b"); g.addColorStop(1,"#1f2937");
      ctx.fillStyle = g; ctx.fillRect(0,0,w,h);
      for (let i=0;i<4;i++){ drawTorch(ctx, (i+1)*w/5, h*0.28); }
      drawDoor(ctx, w*doorX, h*0.62, hasKey);
      if (!hasKey) drawKey(ctx, w*keyX, h*0.65);
      drawHero(ctx, w*heroX, h*0.70, 1.5);
      ctx.fillStyle = "#fff"; ctx.font = "12px ui-sans-serif";
      ctx.fillText("← → / arrows to move, Space/Action to interact.", 12, 18);
      if (stage==="choose") { ctx.fillText("(Muffled fighting sounds)", 12, 36); }
    }

    return ()=>window.removeEventListener("keydown", onKey);
  }

  if (stage === "choose") {
    return (
      <Card>
        <LevelHeader n={4} subtitle="Choose: Hug or Slap?" />
        <div className="grid md:grid-cols-2 gap-6 items-center">
          <div className="relative rounded-xl border border-slate-700 bg-slate-900/50 p-6">
            <div className="text-sm opacity-90 mb-2">You opened the door. Inside, a short‑haired character, <b>Bzr</b>, throws a tantrum — fists in the air, shouting.</div>
            <div className="flex items-center gap-6">
              <HeroSprite scale={1.6} />
              <Bubble>
                <div className="text-sm">What should I do?</div>
                <div className="text-xs opacity-80">(Hug 🤝 or Slap 👋)</div>
              </Bubble>
              <AfroSprite scale={1.6} />
            </div>
          </div>
          <div className="space-y-3">
            <button onClick={()=>{ confettiBurst(); Sound.yay(); onWin(); }}
              className="w-full rounded-xl px-5 py-3 bg-emerald-500 text-slate-900 font-semibold hover:bg-emerald-400">🤝 Hug Bzr</button>
            <button onClick={()=>{ Sound.boo(); }}
              className="w-full rounded-xl px-5 py-3 bg-rose-500/90 text-slate-900 font-semibold hover:bg-rose-400">👋 Slap (wrong)</button>
            <div className="text-xs opacity-80">Hug = confetti + apology. Slap = boo & repeat the checkpoint.</div>
          </div>
        </div>
        <ControlsOverlay onLeft={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowLeft'}))}
                         onRight={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowRight'}))}
                         onAction={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:' '}))}
                         label="Action" />
      </Card>
    );
  }

  return (
    <Card>
      <LevelHeader n={4} subtitle="Castle — find the key, then the door" />
      <div className="rounded-xl overflow-hidden border border-slate-700 bg-black/30">
        <canvas ref={canvasRef} className="w-full" />
      </div>
      <div className="mt-3 text-xs opacity-80">Door is easy to find. After opening, choose kindly.</div>
      <ControlsOverlay onLeft={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowLeft'}))}
                       onRight={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowRight'}))}
                       onAction={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:' '}))}
                       label="Action" />
    </Card>
  );
}

function WinScreen({ onReplay }) {
  return (
    <Card>
      <div className="flex flex-col items-center text-center gap-3 py-6">
        <h2 className="text-2xl font-bold">🎉 You Win!</h2>
        <p className="text-sm opacity-90">Confetti! An apology appears across the hall. Adventure complete.</p>
        <button onClick={onReplay} className="mt-2 rounded-xl px-5 py-3 bg-indigo-400 text-slate-900 font-semibold hover:bg-indigo-300">Play Again</button>
      </div>
    </Card>
  );
}

/** Shared UI bits */
function LevelHeader({ n, subtitle }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <div>
        <div className="text-xs uppercase tracking-wide opacity-70">Checkpoint {n}</div>
        <div className="text-lg font-semibold">{subtitle}</div>
      </div>
      <div className="flex items-center gap-3 text-xs opacity-80">
        <span className="hidden sm:inline">3’bya</span>
        <HeroSprite />
      </div>
    </div>
  );
}

function Tip({ title, children }) {
  return (
    <div className="rounded-xl bg-slate-900/60 border border-slate-700 p-3">
      <div className="text-xs font-semibold mb-1">{title}</div>
      <div className="text-xs opacity-90">{children}</div>
    </div>
  );
}

/** Procedural sprites (original) */
function HeroSprite({ scale=1 }) {
  return (
    <div className="flex items-center gap-1" style={{ transform: `scale(${scale})` }}>
      <div className="relative w-8 h-10">
        {/* Hair (brown curly) */}
        <div className="absolute -top-1 left-0 right-0 h-4 rounded-full bg-amber-800" />
        <div className="absolute top-1 -left-1 w-4 h-4 rounded-full bg-amber-900" />
        <div className="absolute top-1 -right-1 w-4 h-4 rounded-full bg-amber-900" />
        {/* Head */}
        <div className="absolute top-2 left-1 right-1 h-6 rounded-md bg-amber-300" />
        {/* Outfit grey & navy */}
        <div className="absolute bottom-0 left-0 right-0 h-5 rounded-b-xl bg-slate-700" />
        <div className="absolute bottom-3 left-2 right-2 h-2 rounded bg-indigo-700" />
      </div>
    </div>
  );
}

function AfroSprite({ scale=1 }) {
  return (
    <div className="flex items-center gap-1" style={{ transform: `scale(${scale})` }}>
      <div className="relative w-8 h-10">
        {/* Very short curly afro */}
        <div className="absolute -top-1 left-0 right-0 h-3 rounded-full bg-neutral-800" />
        {/* Head */}
        <div className="absolute top-2 left-1 right-1 h-6 rounded-md bg-amber-200" />
        {/* Outfit grey & red */}
        <div className="absolute bottom-0 left-0 right-0 h-5 rounded-b-xl bg-slate-600" />
        <div className="absolute bottom-3 left-2 right-2 h-2 rounded bg-rose-700" />
      </div>
    </div>
  );
}

function Bubble({ children }) {
  return (
    <div className="relative rounded-xl bg-white text-slate-900 px-3 py-2 text-xs shadow-xl">
      {children}
      <div className="absolute -bottom-2 left-6 w-3 h-3 bg-white rotate-45" />
    </div>
  );
}

/** Draw helpers */
function drawCloud(ctx,x,y,r){
  ctx.fillStyle = "rgba(255,255,255,0.9)"; ctx.beginPath();
  for (let i=0;i<5;i++){ ctx.arc(x+i*r*0.35, y+(i%2?0:-4), r*(0.7 + Math.random()*0.2), 0, Math.PI*2); }
  ctx.fill();
}
function roundRect(ctx,x,y,w,h,r){ ctx.beginPath(); ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); }
function drawFish(ctx){
  ctx.save();
  ctx.fillStyle = "#22d3ee"; ctx.beginPath(); ctx.ellipse(0,0,16,8,0,0,Math.PI*2); ctx.fill();
  ctx.fillStyle = "#06b6d4"; ctx.beginPath(); ctx.moveTo(16,0); ctx.lineTo(26,-6); ctx.lineTo(26,6); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#e2e8f0"; ctx.beginPath(); ctx.arc(-6,-2,2,0,Math.PI*2); ctx.fill();
  ctx.restore();
}
function drawQuadBike(ctx,x,y){
  ctx.save(); ctx.translate(x,y);
  ctx.fillStyle = "#1f2937"; ctx.fillRect(-26,-10,52,12);
  ctx.fillStyle = "#3b82f6"; ctx.fillRect(-18,-18,36,10);
  ctx.fillStyle = "#0f172a"; ctx.beginPath(); ctx.arc(-16,6,10,0,Math.PI*2); ctx.arc(16,6,10,0,Math.PI*2); ctx.fill();
  ctx.restore();
}
function drawLaneObj(ctx,x,y,type){
  ctx.save(); ctx.translate(x,y);
  if (type==='heart') { ctx.fillStyle = "#ef4444"; heartPath(ctx,0,0,10); ctx.fill(); }
  else { ctx.font = "24px serif"; ctx.fillText("🐒", -12, 8); }
  ctx.restore();
}
function heartPath(ctx,x,y,s){
  ctx.beginPath(); ctx.moveTo(x,y);
  ctx.bezierCurveTo(x-s,y-s, x-2*s,y+s*0.5, x,y+s*1.5);
  ctx.bezierCurveTo(x+2*s,y+s*0.5, x+s,y-s, x,y);
}
function drawDoor(ctx,x,y,unlocked){
  ctx.save(); ctx.translate(x,y);
  ctx.fillStyle = "#92400e"; ctx.fillRect(-30,-50,60,80);
  ctx.strokeStyle = "#fde68a"; ctx.lineWidth=3; ctx.strokeRect(-30,-50,60,80);
  ctx.fillStyle = unlocked?"#84cc16":"#eab308"; ctx.beginPath(); ctx.arc(20,-10,5,0,Math.PI*2); ctx.fill();
  ctx.restore();
}
function drawKey(ctx,x,y){
  ctx.save(); ctx.translate(x,y);
  ctx.fillStyle = "#facc15"; ctx.fillRect(-12,-4,18,8);
  ctx.beginPath(); ctx.arc(10,0,8,0,Math.PI*2); ctx.strokeStyle="#facc15"; ctx.lineWidth=4; ctx.stroke();
  ctx.restore();
}
function drawTorch(ctx,x,y){
  ctx.save(); ctx.translate(x,y);
  ctx.fillStyle = "#111827"; ctx.fillRect(-4,0,8,30);
  const g = ctx.createLinearGradient(0,-14,0,8); g.addColorStop(0,"#fde047"); g.addColorStop(1,"rgba(253,224,71,0)");
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0,0,14,0,Math.PI*2); ctx.fill();
  ctx.restore();
}
function drawHero(ctx,x,y,scale=1){
  ctx.save(); ctx.translate(x,y); ctx.scale(scale, scale);
  ctx.fillStyle = "#334155"; ctx.fillRect(-8,-18,16,18);
  ctx.fillStyle = "#4338ca"; ctx.fillRect(-6,-18,12,6);
  ctx.fillStyle = "#fbbf24"; ctx.fillRect(-6,-28,12,10);
  ctx.fillStyle = "#a16207"; ctx.beginPath(); ctx.arc(0,-28,8,0,Math.PI*2); ctx.fill();
  ctx.restore();
}

function confettiBurst(){
  const n = 80; const body = document.body; const elems = [];
  for (let i=0;i<n;i++){
    const d = document.createElement('div');
    d.className = 'pointer-events-none fixed top-0 left-1/2 h-2 w-2 rounded-sm';
    d.style.background = `hsl(${Math.floor(Math.random()*360)} 90% 60%)`;
    d.style.transform = `translateX(${(Math.random()*200-100)}px)`;
    d.style.transition = `transform 1200ms cubic-bezier(.2,.8,.2,1), opacity 1200ms`;
    document.body.appendChild(d); elems.push(d);
    setTimeout(()=>{ d.style.transform += ` translateY(${window.innerHeight+100}px) rotate(${Math.random()*720-360}deg)`; d.style.opacity='0'; },10);
  }
  setTimeout(()=>elems.forEach(e=>e.remove()), 1400);
}

function formatTime(s){
  const m = Math.floor(s/60).toString().padStart(2,'0');
  const r = (s%60).toString().padStart(2,'0');
  return `${m}:${r}`;
}
